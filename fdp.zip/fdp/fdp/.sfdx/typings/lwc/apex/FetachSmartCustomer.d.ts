declare module "@salesforce/apex/FetachSmartCustomer.getSmartCustomer" {
  export default function getSmartCustomer(): Promise<any>;
}
