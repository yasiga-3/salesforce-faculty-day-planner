trigger AccountRatingHot on Account (before insert) {
    if(trigger.isinsert && trigger.isbefore){
        for(account acc:trigger.new){
            if(acc.Industry=='media'){
                acc.Rating='Hot';
            }
        }
    }
}