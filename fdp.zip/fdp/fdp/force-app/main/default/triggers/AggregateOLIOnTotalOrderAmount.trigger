trigger AggregateOLIOnTotalOrderAmount on Order_line_item__c (after insert,after update) {
    if(trigger.isinsert && trigger.isafter){
    	orderLineItemHandler.ForInsertTotalAmount(trigger.new);
    }
    if(trigger.isAfter && trigger.isUpdate){
       orderLineItemHandler.ForUpdateTotalAmount(trigger.new,trigger.oldmap);
    }
    /*if(trigger.isAfter && trigger.isDelete){
      orderLineItemHandler.ForDeleteTotalAmount(trigger.old);
    }*/
}