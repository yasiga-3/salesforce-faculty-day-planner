trigger ContactUponAccount on Account (after insert) {
    if(trigger.isInsert && trigger.isAfter){
        AccountHandler.contactCreation(trigger.new);
    }
}