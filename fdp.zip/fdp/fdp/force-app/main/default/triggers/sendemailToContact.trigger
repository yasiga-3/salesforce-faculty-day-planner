trigger sendemailToContact on Contact (after insert) {
    if(trigger.isafter && trigger.isInsert){
        contacthandler.sendEmailsToCustomers(trigger.new);
    }
}