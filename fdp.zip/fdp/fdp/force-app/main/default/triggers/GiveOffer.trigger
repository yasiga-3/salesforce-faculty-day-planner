trigger GiveOffer on smart_customers__c (before insert) {
    if(trigger.isinsert && trigger.isbefore){
        for(smart_customers__c sc:trigger.new){
            if(sc.address__c.contains('chennai')){
                sc.Description__c ='This customer is a local customer please provide offer';
            }
        }
    }
}