trigger sendemailToSmartCustomers on smart_customers__c (after insert) {
	if(trigger.isafter && trigger.isInsert){
        smartcustomershandler.sendEmailsToCustomers(trigger.new);
    }
}